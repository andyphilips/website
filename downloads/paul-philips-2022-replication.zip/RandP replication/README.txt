README

Files:
-figure-1.R: produces Figure 1
-replication.do: produces all other tables/figures
-EconomicNewsAJPS.txt: dataset for analysis
-thresholdtest.ado: user-written .ado file
-thresholdreg.ado: user-written .ado file

