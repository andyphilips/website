# FIGURE 1
# 8/31/21

# this replicates figure 1

set.seed(209520)

# AR:
y.ar <- arima.sim(n=200, list(ar = (c(0.75))), innov = rnorm(200, mean = 0, sd = 2))
plot.ts(y.ar)


# SE-TAR
y.setar <- rnorm(200, sd = 2)
for(i in 2:length(y.setar)){
  if(y.setar[i-1] <= .5){
    y.setar[i] <- 0.75*y.setar[i-1] + rnorm(1, sd = 2)
  }
  else{
    y.setar[i] <- 0.10*y.setar[i-1] + rnorm(1, sd = 2)
  }
}

plot.ts(y.setar)

# 3-regime SETAR
y.3setar <- rnorm(200, sd = 2)
for(i in 2:length(y.setar)){
  if(y.3setar[i-1] <= -1){
    y.3setar[i] <- 0.10*y.3setar[i-1] + rnorm(1, sd = 2)
  }
  else if(y.3setar[i-1] >= 1){
    y.3setar[i] <- 0.10*y.3setar[i-1] + rnorm(1, sd = 2)
  }
  else{
    y.3setar[i] <- 0.75*y.3setar[i-1] + rnorm(1, sd = 2)
  }
}
plot.ts(y.3setar)


dev.off()
pdf("SETAR.pdf")
par(mfrow = c(3,1))
plot.ts(y.ar, lwd = 2, col = "red", main = "Autoregressive", ylab = "Value", xlab = "Time", lty = 1, ylim = c(-8, 8))
plot.ts(y.setar, lwd = 2, col = "blue", main = "2 Regime SETAR", ylab = "Value", xlab = "Time", lty = 1, ylim = c(-8, 8))
abline(h = 0.5)
plot.ts(y.3setar, lwd = 2, col = "gray", main = "3 Regime SETAR", ylab = "Value", xlab = "Time", lty = 1, ylim = c(-8, 8))
abline(h=1)
abline(h = -1)
dev.off()

