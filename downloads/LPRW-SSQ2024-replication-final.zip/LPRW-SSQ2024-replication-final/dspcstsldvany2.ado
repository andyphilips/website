*
*		PROGRAM DSPCSTSLDVANY
*	
*		05/17/21
*		Andrew Q. Philips
*		CU Boulder
* -------------------------------------------------------------------------
* -------------------------------------------------------------------------
* We need a flexible dynsimpie program for LDVs that allows for any type of
* setting of the independent variables and/or interactions. This version
* requires specifying shockdta, which provides the variable names and 
* the desired shock across time, e.g.,
*    VAR1		Var2	Var3	...
*	  0			 0	     1
*     0          1      0
* Note: as of 5/17/21, added additional 90 and 95% CIs
* NOTE: I haven't added anything s.t. you can interact with the LDV. We may
* want this in the future.
* TODO:
* 	-transform proportions to percentages
* -------------------------------------------------------------------------


capture program drop dspcstsldvany
capture program define dspcstsldvany, rclass
syntax [varlist] [if] [in], [ dvs(varlist max = 12) shockdta(string) ///
id(varname) ladderplot shocktime(numlist) basetime(numlist)		///
endtime(numlist) sig(numlist integer < 100) valtype(string) saving(string)] 


version 8
marksample touse
loc n_ivars : word count `varlist' // count of vars


if "`dvs'" == ""	{
	di in r _n "Must specify dependent compositional variables in dvs( )"
	exit 198
}

if "`id'" == "" {
	di in r _n "id must be specified since this is a CSTS program"
	exit 198
}

if "`ladderplot'" != "" {		// if you want to make ladderplot
	if "`shocktime'" == "" | "`basetime'" == "" | "`endtime'" == "" {
		di in r _n "shocktime, basetime, and endtime must all be specified with ladderplot"
		exit 198
	}
}

if "`sig'" != ""	{						// getting the CI's signif
	local signif `sig'
}
else	{
	local signif 95
}
local sigl = (100-`signif')/2
local sigu = 100-((100-`signif')/2)
local sigl90 = 5						// additional 90% CIs
local sigu90 = 95

* for whether we want expected values or predicted values:
if "`valtype'" == "" {
	loc vtype "ev"
}
else {
	loc vtype "`valtype'"
}

* ------------------------Obtain shockdta --------------------------------
preserve
use "`shockdta'", clear
* assert that num vars match up with num vars in varlist
qui de
local varcol = r(k)
if "`varcol'" != "`n_ivars'" {
	di in r _n "The number of columns in shockdta must match the number of independent variables"
	exit 198
}
mkmat `varlist', matrix(shockmatrix)
local r = rowsof(shockmatrix)
local c = colsof(shockmatrix)
restore

mat list shockmatrix

preserve

* ------------------------Generate LDV & run model --------------------------------
loc model
local i 1
qui foreach var of varlist `dvs'	{
	tempvar ldepvar`i'
	bysort `id': gen `ldepvar`i'' = l.`var'
	* get the model:
	local model `"`model' (`var' `ldepvar`i'' `varlist')"'
	local i = `i' + 1
}
local maxdv = `i' - 1					// need # of compositions
qui sureg `model'       
qui keep if e(sample)
noi estsimp sureg `model'

* ------------------------Set Vars, t = 1 --------------------------------------
local i 1
foreach var of varlist `varlist' {
	scalar set = shockmatrix[1,`i']
	setx `var' set
	local i = `i' + 1
}

local i 1
qui foreach var of varlist `dvs'	{	// set lagged DVs to their means
	su `var', meanonly
	scalar m`i' = r(mean)
	setx `ldepvar`i'' m`i'
	local i = `i' + 1
}
*noi setx


* ------------------------Predict t = 1 --------------------------------------
local preddv
loc i 1
qui foreach var of varlist `dvs'	{
	tempvar t`i'log1
	loc preddv `"`preddv' `t`i'log1' "'
	loc i = `i' + 1	
}
qui simqi, `vtype' gen`vtype'(`preddv')

loc denominator1
loc i 1
qui foreach var in `dvs'	{
	su `t`i'log1', meanonly
	scalar m`i' = r(mean)			// these scalars become the new LDV
	loc denominator1 `"`denominator1' + (exp(`t`i'log1'))"'
	loc i = `i' + 1
}



* ------------------------Loop Through Time --------------------------------
di ""
nois _dots 0, title(Simulation in Progress...please wait) reps(`r')
qui forv i = 2/`r' {		// from 1 through all rows of shockmatrix
	noi _dots `i' 0 
	
	forv x = 1/`maxdv'	{			// set new value of LDV 
		setx `ldepvar`x'' (m`x')		
	}
	
	loc z 1
	foreach var of varlist `varlist' {
		scalar set = shockmatrix[`i',`z']
		setx `var' set
		local z = `z' + 1
	}
*noi setx
	local preddv
	qui forv x = 1/`maxdv'	{
		tempvar t`x'log`i'
		local preddv `"`preddv' `t`x'log`i'' "'
	}
	simqi, `vtype' gen`vtype'(`preddv')				// get new predictions
	local denominator`i'
	qui forv x = 1/`maxdv'	{
		su `t`x'log`i'', meanonly
		scalar m`x' = r(mean)
		local denominator`i' `"`denominator`i'' + (exp(`t`x'log`i''))"' // need this for below
	}	
}	// close time loop





* ------------------------Un-Transform------------------------------------------
local keepthese

if "`ladderplot'" != "" {		// if you want to make ladderplot
	* note that after untransforming compositions, starting means are subtracted and
	* percentiles drawn.
	local z = `maxdv' + 1
		qui forv m = 1/`maxdv' {
			tempvar var_pie`basetime'_`m' var_pie`shocktime'_`m' var_pie`endtime'_`m'
			* Create compositions for start time:
			gen `var_pie`basetime'_`m'' = ((exp(`t`m'log`basetime''))/(1  `denominator`basetime''))*100
			_pctile `var_pie`basetime'_`m'', p(50)		// grab midpoint
			gen var_pie_med_`basetime'_`m' = r(r1)
		
			* create composition for shocktime:
			gen `var_pie`shocktime'_`m'' = (((exp(`t`m'log`shocktime''))/(1  `denominator`shocktime'')))*100 - var_pie_med_`basetime'_`m'
			_pctile `var_pie`shocktime'_`m'', p(`sigl',`sigl90',`sigu90',`sigu')
			gen var_pie_ll_sr_`m' = r(r1)
			gen var_pie_ul_sr_`m' = r(r4)
			gen var_pie_ll90_sr_`m' = r(r2)
			gen var_pie_ul90_sr_`m' = r(r3)
		
			* create composition for LR-time:
			gen `var_pie`endtime'_`m'' = ((exp(`t`m'log`endtime''))/(1  `denominator`endtime''))*100 - var_pie_med_`basetime'_`m'
			_pctile `var_pie`endtime'_`m'', p(`sigl',`sigl90',`sigu90',`sigu')
			gen var_pie_ll_lr_`m' = r(r1)
			gen var_pie_ul_lr_`m' = r(r4)
			gen var_pie_ll90_lr_`m' = r(r2)
			gen var_pie_ul90_lr_`m' = r(r3)

			local keepthese `"`keepthese' var_pie_ll_sr_`m' var_pie_ul_sr_`m' var_pie_ll90_sr_`m' var_pie_ul90_sr_`m' var_pie_ll_lr_`m' var_pie_ul_lr_`m' var_pie_ll90_lr_`m' var_pie_ul90_lr_`m' "'
		}				  
		tempvar var_pie`shocktime'_`z' var_pie`endtime'_`z' var_pie`basetime'_`z'  // the un-transformation baseline
		gen `var_pie`basetime'_`z'' = (1/(1  `denominator`basetime''))*100
		_pctile `var_pie`basetime'_`z'', p(50)		// grab midpoint
		gen var_pie_med_`basetime'_`z' = r(r1)
	
		gen `var_pie`shocktime'_`z'' = ((1/(1  `denominator`shocktime'')))*100 - var_pie_med_`basetime'_`z'	
		_pctile `var_pie`shocktime'_`z'', p(`sigl',`sigl90',`sigu90',`sigu')
		gen var_pie_ll_sr_`z' = r(r1)
		gen var_pie_ul_sr_`z' = r(r4)
		gen var_pie_ll90_sr_`z' = r(r2)
		gen var_pie_ul90_sr_`z' = r(r3)
		gen `var_pie`endtime'_`z'' = ((1/(1  `denominator`endtime'')))*100 - var_pie_med_`basetime'_`z'
		_pctile `var_pie`endtime'_`z'', p(`sigl',`sigl90',`sigu90',`sigu')
		gen var_pie_ll_lr_`z' = r(r1)
		gen var_pie_ul_lr_`z' = r(r4)
		gen var_pie_ll90_lr_`z' = r(r2)
		gen var_pie_ul90_lr_`z' = r(r3)
	
		local keepthese `"`keepthese' var_pie_ll_sr_`z' var_pie_ul_sr_`z' var_pie_ll90_sr_`z' var_pie_ul90_sr_`z' var_pie_ll_lr_`z' var_pie_ul_lr_`z' var_pie_ll90_lr_`z' var_pie_ul90_lr_`z' "'

	keep `keepthese'
	qui keep in 1

	gen count = _n
	reshape long var_pie_ll_sr_ var_pie_ul_sr_ var_pie_ll90_sr_ var_pie_ul90_sr_ var_pie_ll_lr_ var_pie_ul_lr_ var_pie_ll90_lr_ var_pie_ul90_lr_, j(sort) i(count)
	gen sort_lr = sort - 0.2
	gen sort_sr = sort + 0.2

	* create midpoints:
	gen mid_sr = (var_pie_ll_sr_ + var_pie_ul_sr_)/2
	gen mid_lr = (var_pie_ll_lr_ + var_pie_ul_lr_)/2
}

else {							// otherwise change-from-baseline
	local z = `maxdv' + 1
	qui forv i = 1/`r'	{
		qui forv m = 1/`maxdv'	{
			tempvar var`m'_pie`i'
			gen `var`m'_pie`i'' = ((exp(`t`m'log`i''))/(1 `denominator`i''))*100
			_pctile `var`m'_pie`i'', p(`sigl',`sigl90',`sigu90',`sigu')			// grab CIs for each DV
			gen var`m'_pie_ll_`i' = r(r1) 
			gen var`m'_pie_ul_`i' = r(r4) 
			gen var`m'_pie_ll90_`i' = r(r2)
			gen var`m'_pie_ul90_`i' = r(r3)
			loc keepthese `"`keepthese' var`m'_pie_ll_`i' var`m'_pie_ul_`i' var`m'_pie_ll90_`i' var`m'_pie_ul90_`i' "'
		}
		tempvar var`z'_pie`i'				// for the untransformation baseline
		gen `var`z'_pie`i'' = (1/(1 `denominator`i''))*100
		_pctile `var`z'_pie`i'', p(`sigl',`sigl90',`sigu90',`sigu')
		gen var`z'_pie_ll_`i' = r(r1) 
		gen var`z'_pie_ul_`i' = r(r4)
		gen var`z'_pie_ll90_`i' = r(r2)
		gen var`z'_pie_ul90_`i' = r(r3)
		loc keepthese `"`keepthese' var`z'_pie_ll_`i' var`z'_pie_ul_`i' var`z'_pie_ll90_`i' var`z'_pie_ul90_`i' "'
	}

	keep `keepthese'
	qui keep in 1
	tempvar count
	qui gen `count' = _n

	local reshapevar
	local maxvars = `maxdv' + 1				// get max # of DVs
	qui forv i = 1/`maxvars'	{
		local reshapevar `"`reshapevar' var`i'_pie_ll_ var`i'_pie_ul_ var`i'_pie_ll90_ var`i'_pie_ul90_ "'
	}

	qui reshape long `reshapevar', j(time) i(`count')
	qui drop `count'

	qui forv i = 1/`maxvars'	{
		gen mid`i' = (var`i'_pie_ll_ + var`i'_pie_ul_)/2
	}
}



di ""
if "`saving'" != ""	{
	noi save `saving'.dta, replace
}
else	{
	noi save dynsimpie_results.dta, replace
}

restore 				// so saved values are removed from dataset

end 										// end
* ----------------------------------------------------------------------------


