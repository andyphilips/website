*
*
* SSQ replication
* -------------------------------------

clear
clear matrix
clear mata
set scheme burd, perm
set seed 2000291
global user "Andy"
if "$user" == "Andy"	{
	global path "/Users/aqpimac/Dropbox"
	set maxvar 10000
}
set more off, perm


* Init programs
cd "${path}/Lipsmeyer_Philips_Rutherford_Whitten"

* program to use matrix to create any type of shock we desire:
do "dspcstsldvany2.ado"


use "categories_new.dta", clear



* -------------- SOME DATA WORK -------------------------------------------
* need to recode all of these:
gen fips = .
replace fips = 1 if Name == "AL STATE GOVT"
replace fips = 4 if Name == "AZ STATE GOVT"
replace fips = 5 if Name == "AR STATE GOVT"
replace fips = 6 if Name == "CA STATE GOVT"
replace fips = 8 if Name == "CO STATE GOVT"
replace fips = 9 if Name == "CT STATE GOVT"
replace fips = 10 if Name == "DE STATE GOVT"
replace fips = 12 if Name == "FL STATE GOVT"
replace fips = 13 if Name == "GA STATE GOVT"
replace fips = 16 if Name == "ID STATE GOVT"
replace fips = 17 if Name == "IL STATE GOVT"
replace fips = 18 if Name == "IN STATE GOVT"
replace fips = 19 if Name == "IA STATE GOVT"
replace fips = 20 if Name == "KS STATE GOVT"
replace fips = 21 if Name == "KY STATE GOVT"
replace fips = 22 if Name == "LA STATE GOVT"
replace fips = 23 if Name == "ME STATE GOVT"
replace fips = 24 if Name == "MD STATE GOVT"
replace fips = 25 if Name == "MA STATE GOVT"
replace fips = 26 if Name == "MI STATE GOVT"
replace fips = 27 if Name == "MN STATE GOVT"
replace fips = 28 if Name == "MS STATE GOVT"
replace fips = 29 if Name == "MO STATE GOVT"
replace fips = 30 if Name == "MT STATE GOVT"
replace fips = 31 if Name == "NE STATE GOVT"
replace fips = 32 if Name == "NV STATE GOVT"
replace fips = 33 if Name == "NH STATE GOVT"
replace fips = 34 if Name == "NJ STATE GOVT"
replace fips = 35 if Name == "NM STATE GOVT"
replace fips = 36 if Name == "NY STATE GOVT"
replace fips = 37 if Name == "NC STATE GOVT"
replace fips = 38 if Name == "ND STATE GOVT"
replace fips = 39 if Name == "OH STATE GOVT"
replace fips = 40 if Name == "OK STATE GOVT"
replace fips = 41 if Name == "OR STATE GOVT"
replace fips = 42 if Name == "PA STATE GOVT"
replace fips = 44 if Name == "RI STATE GOVT"
replace fips = 45 if Name == "SC STATE GOVT"
replace fips = 46 if Name == "SD STATE GOVT"
replace fips = 47 if Name == "TN STATE GOVT"
replace fips = 48 if Name == "TX STATE GOVT"
replace fips = 49 if Name == "UT STATE GOVT"
replace fips = 50 if Name == "VT STATE GOVT"
replace fips = 51 if Name == "VA STATE GOVT"
replace fips = 53 if Name == "WA STATE GOVT"
replace fips = 54 if Name == "WV STATE GOVT"
replace fips = 55 if Name == "WI STATE GOVT"
replace fips = 56 if Name == "WY STATE GOVT"

joinby fips year using "MPSA 2015/panel_wcontrols_SpatX.dta", unmatched(both)
list fips Name year if _merge != 3
drop if _merge != 3



* create some variables:
gen demgov = .
replace demgov = 0 if govparty_c != .
replace demgov = 1 if govparty_c == 1   // Democratic gov
gen senate_dems_pct = (sen_dem_in_sess/sen_tot_in_sess)*100
cap drop house_dems_pct
gen house_dems_pct =  (hs_dem_in_sess/hs_tot_in_sess)*100

* unified govt (any party)
gen uall = 0
replace uall = 1 if demgov == 1 & house_dems_pct > 50 & senate_dems_pct > 50
replace uall = 1 if demgov == 0 & house_dems_pct < 50 & senate_dems_pct <50
* unified govt (left unified)
gen ualldem = 0
replace ualldem = 1 if demgov == 1 & house_dems_pct > 50 & senate_dems_pct > 50
* unified legislature (any party)
gen uleg = 0
replace uleg = 1 if house_dems_pct > 50 & senate_dems_pct > 50
replace uleg = 1 if house_dems_pct < 50 & senate_dems_pct < 50
* unified legislature (left unified)
gen ulegdem = 0
replace ulegdem = 1 if house_dems_pct > 50 & senate_dems_pct > 50

tab demgov
tab uall
tab ualldem
tab uleg
tab ulegdem

* create t-logit of our 10-categories:
tlogit pct_eled eled_ss	///
	pct_hed hed_ss	///
	pct_trans trans_ss	///
	pct_safety safety_ss ///
	pct_env env_ss	///
	pct_hous hous_ss	///
	pct_lm lm_ss	///
	pct_debt debt_ss	///
	pct_other	other_ss,base(pct_ss)
	
	
* -----------------------------------------------------------------------
* some graph globals:
global dvs "eled_ss hed_ss trans_ss safety_ss env_ss hous_ss lm_ss debt_ss other_ss"

global spikeopts95 "horizontal lcolor(black) lwidth(medthin)"

global graphmakersr "twoway rspike var_pie_ul_sr_dem var_pie_ll_sr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_sr_rep var_pie_ll_sr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_srdem, msymbol(T) mcolor("edkblue") msize(medlarge) || scatter sort_rep mid_srrep, msymbol(O) mcolor("maroon") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order(3 "Democratic Governor" 4 "Republican Governor") size(small)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Short-Run", size(medium))"

global graphmakerlr "twoway rspike var_pie_ul_lr_dem var_pie_ll_lr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_lr_rep var_pie_ll_lr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_lrdem, msymbol(T) mcolor("edkblue") msize(medlarge) || scatter sort_rep mid_lrrep, msymbol(O) mcolor("maroon") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order(3 "Democratic Governor" 4 "Republican Governor") size(small)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Long-Run", size(medium))"

global graphmakersrpartyswitch "twoway rspike var_pie_ul_sr_dem var_pie_ll_sr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_sr_rep var_pie_ll_sr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_srdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_srrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order(3 "Republican to Democrat Governor" 4 "Democrat to Republican Governor") size(vsmall)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Short-Run", size(medium))"

global graphmakerlrpartyswitch "twoway rspike var_pie_ul_lr_dem var_pie_ll_lr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_lr_rep var_pie_ll_lr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_lrdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_lrrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order(3 "Republican to Democrat Governor" 4 "Democrat to Republican Governor") size(vsmall)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Long-Run", size(medium))"


* Get summary of in-sample shocks:
xtset fips year
qui reg $dvs inflation totallarge unemployment  Wed_unemployment1 ownsource_rev  Wed_real_pincome_pc1 real_pincome_pc demgov //lunified
gen tabbs = 0
replace tabbs = 1 if e(sample)
tab year if tabbs == 1
sort fips year
xtsum real_pincome_pc if tabbs == 1	// 1sd overall = 6.986
xtsum d.real_pincome_pc if tabbs == 1	//
xtsum Wed_real_pincome_pc1 if tabbs == 1	// 43.08737 
xtsum d.Wed_real_pincome_pc1 if tabbs == 1	//
xtsum inflation if tabbs == 1	//  1.779
xtsum d.inflation if tabbs == 1	//
xtsum unemployment if tabbs == 1	// 1.987
xtsum d.unemployment if tabbs == 1	//
xtsum Wed_unemployment1 if tabbs == 1	//  4.567411
xtsum d.Wed_unemployment1 if tabbs == 1	// 
xtsum Wed_inflation1 if tabbs == 1 // 8.323823
xtsum d.Wed_inflation1 if tabbs == 1 //

* OUR FINAL DECISION FOR SHOCKS: 1sd for domestic changes, 1/2 sd for out-of state ones:
*	real_pincome_pc = 6.986
*	Wed_real_pincome_pc1 = 21.543685
*	inflation =  1.779
*	unemployment = 1.987
*	Wed_unemployment = 4.6411845
* 	Wed_inflation = 4.1619115


keep $dvs inflation totallarge unemployment Wed_unemployment1 ownsource_rev ///
	Wed_real_pincome_pc1 Wed_inflation1 real_pincome_pc demgov fips year ///
	uall ualldem uleg ulegdem tabbs

* Lag all X's, and also interact them with demgov
foreach var of varlist unemployment inflation Wed_unemployment1 Wed_real_pincome_pc1 ownsource_rev totallarge real_pincome_pc {
	gen `var'_dem = `var'*demgov
	gen l`var'_dem = l.`var'_dem 
	gen l`var' = l.`var'
}
gen ldemgov = l.demgov

* do the same for the other unified govt vars:

foreach govtype of varlist uall ualldem uleg ulegdem {
	foreach var of varlist unemployment inflation Wed_unemployment1 Wed_real_pincome_pc1 ownsource_rev totallarge real_pincome_pc {
	gen `var'_`govtype' = `var'*`govtype'
	gen l`var'_`govtype' = l.`var'_`govtype'
	}
	gen l`govtype' = l.`govtype'
}


* ---------------------------------------------------------------------------
*	Figure 1: Drop in within-state personal income (ssq-fig-ownincome-sr.pdf and ssq-fig-ownincome-lr.pdf) for SR and LR PDFs, respectively
* create necessary interactions:
gen income_demgov = real_pincome_pc*demgov
gen lincome_demgov = lreal_pincome_pc*ldemgov
* ---------------------------------------------------------------------------
* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownincome*demgov + l.(ownincome*demgov). In other words we're only interacting the variable of interest with demgov, rather than everything; this is what we do in the CUP book

* first one, we'll do demgov == 1
set seed 29202094
* init mat:
mat smat = J(100, 18, .) // t = 100, k = 18
mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "demgov" "ldemgov" "income_demgov" "lincome_demgov"
loc r = rowsof(smat)

* unemployment and lag: means
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 1] = r(mean)
	mat smat[`i', 2] = r(mean)
}
* inflation and lag: means
su inflation if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 3] = r(mean)
	mat smat[`i', 4] = r(mean)
}
* Wed_unemployment and lag: means
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 5] = r(mean)
	mat smat[`i', 6] = r(mean)
}
* Wed_real_pincome_pc1 and lag: means
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 7] = r(mean)
	mat smat[`i', 8] = r(mean)
}
* ownsource_rev and lag: means
su ownsource_rev if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 9] = r(mean)
	mat smat[`i', 10] = r(mean)
}
* totallarge and lag: means
su totallarge if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 11] = r(mean)
	mat smat[`i', 12] = r(mean)
}
* real_pincome_pc (mean - 1sd at t=55) and lag (mean - 1sd at t=56)
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 13] = r(mean) - r(sd)
	}
	else {
		mat smat[`i', 13] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 14] = r(mean) - r(sd)
	}
	else {
		mat smat[`i', 14] = r(mean)
	}
}
* demgov and lag: ==1
forv i = 1/`r' {
	mat smat[`i', 15] = 1
	mat smat[`i', 16] = 1
}
* real_pincome_pc*demgov and lag: (mean - 1sd at t=55) and lag (mean - 1sd at t=56) 
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 17] = r(mean) - r(sd)
	}
	else {
		mat smat[`i', 17] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 18] = r(mean) - r(sd)
	}
	else {
		mat smat[`i', 18] = r(mean)
	}
}
mat list smat

preserve
clear
svmat smat, names(col)
saveold "savedshocks_dem.dta", replace version(11)
restore 

* Now do the same for rep, only changes are for demgov and the interaction:
* demgov and lag: ==0
forv i = 1/`r' {
	mat smat[`i', 15] = 0
	mat smat[`i', 16] = 0
}
* real_pincome_pc*demgov and lag: 0
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 17] = 0
	mat smat[`i', 18] = 0
}
mat list smat
preserve
clear
svmat smat, names(col)
saveold "savedshocks_rep.dta", replace version(11)
restore 

* Run program: effectsplot, for dem
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov income_demgov lincome_demgov, shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
* Run program: effectsplot, for rep
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov income_demgov lincome_demgov, shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
preserve
use dem_results.dta, clear
/* order:
 sort = 1: elementary ed
 sort = 2: higher education
 = 3: transportation
 = 4: public safety
 = 5: natural resources & sanitation
 = 6: housing
 = 7: labor market policy
 = 8: interest on debt
 = 9: other
 = 10: social services (baseline)
 
 And sort_lr will be used for Dem (sort_dem), and sort_sr (sort_rep) for rep
*/
rename sort_lr sort_dem
rename sort_sr sort_rep
foreach var of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
	rename `var' `var'dem
}
joinby sort using rep_results.dta
foreach var of varlist var_pie_ll_sr_ - mid_lr {
	rename `var' `var'rep
}
 
* plot SR and LR across party:
$graphmakersr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownincome-sr.pdf", as(pdf) replace
$graphmakerlr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownincome-lr.pdf", as(pdf) replace
restore 


* ---------------------------------------------------------------------------
*	Figure 2: Rise in own unemployment (ssq-fig-ownunemployment-sr.pdf and ssq-fig-ownunemployment-lr.pdf) for SR and LR PDFs, respectively
* create necessary interactions:
gen unemployment_demgov = unemployment*demgov
gen lunemployment_demgov = lunemployment*ldemgov
* ---------------------------------------------------------------------------
* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*demgov + l.(ownunemployment*demgov). In other words we're only interacting the variable of interest with demgov, rather than everything; this is what we do in the CUP book

* first one, we'll do demgov == 1
set seed 29202094
* init mat:
mat smat = J(100, 18, .) // t = 100, k = 18
mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "demgov" "ldemgov" "unemployment_demgov" "lunemployment_demgov" 
loc r = rowsof(smat) 

* unemployment and lag: (mean + 1sd at t=55) and lag (mean + 1sd at t=56)
su unemployment if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 1] = r(mean) + r(sd)
	}
	else {
		mat smat[`i', 1] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 2] = r(mean) + r(sd)
	}
	else {
		mat smat[`i', 2] = r(mean)
	}
}
* inflation and lag: means
su inflation if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 3] = r(mean)
	mat smat[`i', 4] = r(mean)
}
* Wed_unemployment and lag: means
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 5] = r(mean)
	mat smat[`i', 6] = r(mean)
}
* Wed_real_pincome_pc1 and lag: means
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 7] = r(mean)
	mat smat[`i', 8] = r(mean)
}
* ownsource_rev and lag: means
su ownsource_rev if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 9] = r(mean)
	mat smat[`i', 10] = r(mean)
}
* totallarge and lag: means
su totallarge if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 11] = r(mean)
	mat smat[`i', 12] = r(mean)
}
* real_pincome_pc: means
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 13] = r(mean)
	mat smat[`i', 14] = r(mean)
}
* demgov and lag: ==1
forv i = 1/`r' {
	mat smat[`i', 15] = 1
	mat smat[`i', 16] = 1
}
* unemployment*demgov and lag: (mean + 1sd at t=55) and lag (mean + 1sd at t=56) 
su unemployment if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 17] = r(mean) + r(sd)
	}
	else {
		mat smat[`i', 17] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 18] = r(mean) + r(sd)
	}
	else {
		mat smat[`i', 18] = r(mean)
	}
}
mat list smat

preserve
clear
svmat smat, names(col)
saveold "savedshocks_dem.dta", replace version(11)
restore 

* Now do the same for rep, only changes are for demgov and the interaction:
* demgov and lag: ==0
forv i = 1/`r' {
	mat smat[`i', 15] = 0
	mat smat[`i', 16] = 0
}
* real_pincome_pc*demgov and lag: 0
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 17] = 0
	mat smat[`i', 18] = 0
}
mat list smat
preserve
clear
svmat smat, names(col)
saveold "savedshocks_rep.dta", replace version(11)
restore 

* Run program: effectsplot, for dem
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov unemployment_demgov lunemployment_demgov, shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
* Run program: effectsplot, for rep
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov unemployment_demgov lunemployment_demgov, shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
preserve
use dem_results.dta, clear
/* order:
 sort = 1: elementary ed
 sort = 2: higher education
 = 3: transportation
 = 4: public safety
 = 5: natural resources & sanitation
 = 6: housing
 = 7: labor market policy
 = 8: interest on debt
 = 9: other
 = 10: social services (baseline)
 
 And sort_lr will be used for Dem (sort_dem), and sort_sr (sort_rep) for rep
*/
rename sort_lr sort_dem
rename sort_sr sort_rep
foreach var of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
	rename `var' `var'dem
}
joinby sort using rep_results.dta
foreach var of varlist var_pie_ll_sr_ - mid_lr {
	rename `var' `var'rep
}
 
* plot SR and LR across party:
$graphmakersr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownunemployment-sr.pdf", as(pdf) replace
$graphmakerlr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownunemployment-lr.pdf", as(pdf) replace
restore 


* ---------------------------------------------------------------------------
*	Figure 3: Drop in surrounding personal income (ssq-fig-surroundincome-sr.pdf and ssq-fig-surroundincome-lr.pdf) for SR and LR PDFs, respectively
* create necessary interactions:
gen Wincome_demgov = Wed_real_pincome_pc1*demgov
gen lWincome_demgov = lWed_real_pincome_pc1*ldemgov
* ---------------------------------------------------------------------------
* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*demgov + l.(ownunemployment*demgov). In other words we're only interacting the variable of interest with demgov, rather than everything; this is what we do in the CUP book 

* first one, we'll do demgov == 1
set seed 29202094
* init mat:
mat smat = J(100, 18, .) // t = 100, k = 18
mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "demgov" "ldemgov" "Wincome_demgov" "lWincome_demgov" 
loc r = rowsof(smat) 

* unemployment and lag: means
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 1] = r(mean)
	mat smat[`i', 2] = r(mean)
}
* inflation and lag: means
su inflation if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 3] = r(mean)
	mat smat[`i', 4] = r(mean)
}
* Wed_unemployment and lag: means
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 5] = r(mean)
	mat smat[`i', 6] = r(mean)
}
* Wed_real_pincome_pc1 and lag: (mean - .5sd at t=55) and lag (mean - .5sd at t=56)
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 7] = r(mean) - (.5*r(sd))
	}
	else {
		mat smat[`i', 7] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 8] = r(mean) - (.5*r(sd))
	}
	else {
		mat smat[`i', 8] = r(mean)
	}
}
* ownsource_rev and lag: means
su ownsource_rev if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 9] = r(mean)
	mat smat[`i', 10] = r(mean)
}
* totallarge and lag: means
su totallarge if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 11] = r(mean)
	mat smat[`i', 12] = r(mean)
}
* real_pincome_pc: means
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 13] = r(mean)
	mat smat[`i', 14] = r(mean)
}
* demgov and lag: ==1
forv i = 1/`r' {
	mat smat[`i', 15] = 1
	mat smat[`i', 16] = 1
}
* Wed_real_pincome_pc1*demgov and lag: (mean - .5sd at t=55) and lag (mean - .5sd at t=56) 
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 17] = r(mean) - (r(sd)*.5)
	}
	else {
		mat smat[`i', 17] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 18] = r(mean) - (r(sd)*.5)
	}
	else {
		mat smat[`i', 18] = r(mean)
	}
}
mat list smat

preserve
clear
svmat smat, names(col)
saveold "savedshocks_dem.dta", replace version(11)
restore 

* Now do the same for rep, only changes are for demgov and the interaction:
* demgov and lag: ==0
forv i = 1/`r' {
	mat smat[`i', 15] = 0
	mat smat[`i', 16] = 0
}
* Wed_real_pincome_pc1*demgov and lag: 0
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 17] = 0
	mat smat[`i', 18] = 0
}
mat list smat
preserve
clear
svmat smat, names(col)
saveold "savedshocks_rep.dta", replace version(11)
restore 

* Run program: effectsplot, for dem
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov Wincome_demgov lWincome_demgov, shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
* Run program: effectsplot, for rep
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov Wincome_demgov lWincome_demgov, shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
preserve
use dem_results.dta, clear
/* order:
 sort = 1: elementary ed
 sort = 2: higher education
 = 3: transportation
 = 4: public safety
 = 5: natural resources & sanitation
 = 6: housing
 = 7: labor market policy
 = 8: interest on debt
 = 9: other
 = 10: social services (baseline)
 
 And sort_lr will be used for Dem (sort_dem), and sort_sr (sort_rep) for rep
*/
rename sort_lr sort_dem
rename sort_sr sort_rep
foreach var of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
	rename `var' `var'dem
}
joinby sort using rep_results.dta
foreach var of varlist var_pie_ll_sr_ - mid_lr {
	rename `var' `var'rep
}
 
* plot SR and LR across party:
$graphmakersr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundincome-sr.pdf", as(pdf) replace
$graphmakerlr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundincome-lr.pdf", as(pdf) replace
restore 




* ---------------------------------------------------------------------------
*	Figure 4: Rise in surrounding unemployment (ssq-fig-surroundunemployment-sr.pdf and ssq-fig-surroundunemployment-lr.pdf) for SR and LR PDFs, respectively
* create necessary interactions:
gen Wunemployment_demgov = Wed_unemployment1*demgov
gen lWunemployment_demgov = lWed_unemployment1*ldemgov
* ---------------------------------------------------------------------------
* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*demgov + l.(ownunemployment*demgov). In other words we're only interacting the variable of interest with demgov, rather than everything; this is what we do in the CUP book 

* first one, we'll do demgov == 1
set seed 29202094
* init mat:
mat smat = J(100, 18, .) // t = 100, k = 18
mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "demgov" "ldemgov" "Wunemployment_demgov" "lWunemployment_demgov" 
loc r = rowsof(smat) 

* unemployment and lag: means
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 1] = r(mean)
	mat smat[`i', 2] = r(mean)
}
* inflation and lag: means
su inflation if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 3] = r(mean)
	mat smat[`i', 4] = r(mean)
}
* Wed_unemployment and lag: (mean + .5sd at t=55) and lag (mean + .5sd at t=56)
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 5] = r(mean) + (.5*r(sd))
	}
	else {
		mat smat[`i', 5] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 6] = r(mean) + (.5*r(sd))
	}
	else {
		mat smat[`i', 6] = r(mean)
	}
}
* Wed_real_pincome_pc1 and lag: means
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 7] = r(mean)
	mat smat[`i', 8] = r(mean)
}
* ownsource_rev and lag: means
su ownsource_rev if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 9] = r(mean)
	mat smat[`i', 10] = r(mean)
}
* totallarge and lag: means
su totallarge if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 11] = r(mean)
	mat smat[`i', 12] = r(mean)
}
* real_pincome_pc: means
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 13] = r(mean)
	mat smat[`i', 14] = r(mean)
}
* demgov and lag: ==1
forv i = 1/`r' {
	mat smat[`i', 15] = 1
	mat smat[`i', 16] = 1
}
* Wed_unemployment1*demgov and lag: (mean + .5sd at t=55) and lag (mean + 1sd at t=56) 
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 17] = r(mean) + (r(sd)*.5)
	}
	else {
		mat smat[`i', 17] = r(mean)
	}
	if `i' >= 56 {
		mat smat[`i', 18] = r(mean) + (r(sd)*.5)
	}
	else {
		mat smat[`i', 18] = r(mean)
	}
}
mat list smat

preserve
clear
svmat smat, names(col)
saveold "savedshocks_dem.dta", replace version(11)
restore 

* Now do the same for rep, only changes are for demgov and the interaction:
* demgov and lag: ==0
forv i = 1/`r' {
	mat smat[`i', 15] = 0
	mat smat[`i', 16] = 0
}
* Wed_real_pincome_pc1*demgov and lag: 0
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 17] = 0
	mat smat[`i', 18] = 0
}
mat list smat
preserve
clear
svmat smat, names(col)
saveold "savedshocks_rep.dta", replace version(11)
restore 

* Run program: effectsplot, for dem
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov Wunemployment_demgov lWunemployment_demgov, shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
* Run program: effectsplot, for rep
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov Wunemployment_demgov lWunemployment_demgov, shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
preserve
use dem_results.dta, clear
/* order:
 sort = 1: elementary ed
 sort = 2: higher education
 = 3: transportation
 = 4: public safety
 = 5: natural resources & sanitation
 = 6: housing
 = 7: labor market policy
 = 8: interest on debt
 = 9: other
 = 10: social services (baseline)
 
 And sort_lr will be used for Dem (sort_dem), and sort_sr (sort_rep) for rep
*/
rename sort_lr sort_dem
rename sort_sr sort_rep
foreach var of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
	rename `var' `var'dem
}
joinby sort using rep_results.dta
foreach var of varlist var_pie_ll_sr_ - mid_lr {
	rename `var' `var'rep
}
 
* plot SR and LR across party:
$graphmakersr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundunemployment-sr.pdf", as(pdf) replace
$graphmakerlr
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundunemployment-lr.pdf", as(pdf) replace
restore 


* ---------------------------------------------------------------------------
*	Figure 5: party switching (ssq-fig-partyswitch-sr.pdf and ssq-fig-partyswitch-lr.pdf) for SR and LR PDFs, respectively

* ---------------------------------------------------------------------------
* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*demgov + l.(ownunemployment*demgov). In other words we're only interacting the variable of interest with demgov, rather than everything; this is what we do in the CUP book 

* first one, we'll do demgov == 1
set seed 29202094
* init mat:
mat smat = J(100, 16, .) // t = 100, k = 16
mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "demgov" "ldemgov" 
loc r = rowsof(smat) 

* unemployment and lag: means
su unemployment if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 1] = r(mean)
	mat smat[`i', 2] = r(mean)
}
* inflation and lag: means
su inflation if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 3] = r(mean)
	mat smat[`i', 4] = r(mean)
}
* Wed_unemployment and lag: means
su Wed_unemployment1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 5] = r(mean)
	mat smat[`i', 6] = r(mean)
}
* Wed_real_pincome_pc1 and lag: means
su Wed_real_pincome_pc1 if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 7] = r(mean)
	mat smat[`i', 8] = r(mean)
}
* ownsource_rev and lag: means
su ownsource_rev if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 9] = r(mean)
	mat smat[`i', 10] = r(mean)
}
* totallarge and lag: means
su totallarge if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 11] = r(mean)
	mat smat[`i', 12] = r(mean)
}
* real_pincome_pc: means
su real_pincome_pc if tabbs == 1
forv i = 1/`r' {
	mat smat[`i', 13] = r(mean)
	mat smat[`i', 14] = r(mean)
}
* demgov and lag: == 0 til 55, then 1 (lag gets = 1 at t=56)
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 15] = 1
	}
	else {
		mat smat[`i', 15] = 0
	}
	if `i' >= 56 {
		mat smat[`i', 16] = 1
	}
	else {
		mat smat[`i', 16] = 0
	}
}
mat list smat

preserve
clear
svmat smat, names(col)
saveold "savedshocks_dem.dta", replace version(11)
restore 

* Now do the same for dem to rep
forv i = 1/`r' {
	if `i' >= 55 {
		mat smat[`i', 15] = 0
	}
	else {
		mat smat[`i', 15] = 1
	}
	if `i' >= 56 {
		mat smat[`i', 16] = 0
	}
	else {
		mat smat[`i', 16] = 1
	}
}

mat list smat
preserve
clear
svmat smat, names(col)
saveold "savedshocks_rep.dta", replace version(11)
restore 

* Run program: effectsplot, for rep -> dem
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov, shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
* Run program: effectsplot, for rep
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov, shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
preserve
use dem_results.dta, clear
/* order:
 sort = 1: elementary ed
 sort = 2: higher education
 = 3: transportation
 = 4: public safety
 = 5: natural resources & sanitation
 = 6: housing
 = 7: labor market policy
 = 8: interest on debt
 = 9: other
 = 10: social services (baseline)
 
 And sort_lr will be used for Dem (sort_dem), and sort_sr (sort_rep) for rep
*/
rename sort_lr sort_dem
rename sort_sr sort_rep
foreach var of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
	rename `var' `var'dem
}
joinby sort using rep_results.dta
foreach var of varlist var_pie_ll_sr_ - mid_lr {
	rename `var' `var'rep
}
 
* plot SR and LR across party:
$graphmakersrpartyswitch
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-partyswitch-sr.pdf", as(pdf) replace
$graphmakerlrpartyswitch
graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-partyswitch-lr.pdf", as(pdf) replace
restore 





















* --------------------------------------------------------------------------
* below, looking at the unified legislature/govt as robustness checks to include in SI:
/* unified conditions:
	--uall = unified govt (any party)
	--ualldem = unified govt (left unified only)
	--uleg = unified legislature (any party)
	--ulegdem = unified legislature (left unified only)
*/
* ---------------------------------------------------------------------------


* turn this into a loop so this do file doesn't get crazy. We need to change the graph labels each round
foreach var of varlist uall ualldem uleg ulegdem {
	* apply labels by var
	if "`var'" == "uall" {
		global govtype1 "3 "Unified (All)" 4 "Non-Unified""
		global govtype2 "3 "Unified (All) to Non-Unified" 4 "Non-Unified to Unified (All)""
	} 
	else if "`var'" == "ualldem" {
		global govtype1 "3 "Unified (Dem)" 4 "Non-Unified""
		global govtype2 "3 "Unified (Dem) to Non-Unified" 4 "Non-Unified to Unified (Dem)""
	}
	else if "`var'" == "uleg" {
		global govtype1 "3 "Unified Legislature" 4 "Non-Unified""
		global govtype2 "3 "Unified Legislature to Non-Unified" 4 "Non-Unified to Unified Legislature""
	}
	else {
		global govtype1 "3 "Unified Legislature (Dem)" 4 "Non-Unified""
		global govtype2 "3 "Unified Legislature (Dem) to Non-Unified" 4 "Non-Unified to Unified Legislature (Dem)""
	}
	
	global graphmakersr "twoway rspike var_pie_ul_sr_dem var_pie_ll_sr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_sr_rep var_pie_ll_sr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_srdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_srrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order($govtype1) size(small)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Short-Run", size(medium))"

	global graphmakerlr "twoway rspike var_pie_ul_lr_dem var_pie_ll_lr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_lr_rep var_pie_ll_lr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_lrdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_lrrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order($govtype1) size(small)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Long-Run", size(medium))"

	global graphmakersrpartyswitch "twoway rspike var_pie_ul_sr_dem var_pie_ll_sr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_sr_rep var_pie_ll_sr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_srdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_srrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order($govtype2) size(vsmall)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Short-Run", size(medium))"

	global graphmakerlrpartyswitch "twoway rspike var_pie_ul_lr_dem var_pie_ll_lr_dem sort_dem, $spikeopts95 || rspike var_pie_ul_lr_rep var_pie_ll_lr_rep sort_rep, $spikeopts95 || scatter sort_dem mid_lrdem, msymbol(T) mcolor("gray") msize(medlarge) || scatter sort_rep mid_lrrep, msymbol(O) mcolor("black") msize(medlarge) xline(0, lcolor(black) lstyle(solid)) yscale(axis(1) noline) xlabel(, grid glcolor(gs15)) plotregion(style(none)) legend(order($govtype2) size(vsmall)) xtitle("Predicted Change from Baseline", size(small)) ylabel(1 "Elementary Education" 2 "Higher Education" 3 "Transportation" 4 "Public Safety" 5 "Natl. Resources & Sanitation" 6 "Housing" 7 "Labor Market Policy" 8 "Interest on Debt" 9 "Other" 10 "Social Services", labsize(small)) title("Long-Run", size(medium))"

	
	* ---------------------------------------------------------------------------
	*	Figure 1: Drop in within-state personal income (ssq-fig-ownincome-sr.pdf and ssq-fig-ownincome-lr.pdf) for SR and LR PDFs, respectively
	* create necessary interactions:
	cap gen income_`var' = real_pincome_pc*`var'
	cap gen lincome_`var' = lreal_pincome_pc*l`var'
	* ---------------------------------------------------------------------------
	* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownincome*`var' + l.(ownincome*`var'). In other words we're only interacting the variable of interest with `var', rather than everything; this is what we do in the CUP book

	* first one, we'll do `var' == 1
	set seed 29202094
	* init mat:
	mat smat = J(100, 18, .) // t = 100, k = 18
	mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "`var'" "l`var'" "income_`var'" "lincome_`var'"
	loc r = rowsof(smat)

	* unemployment and lag: means
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 1] = r(mean)
		mat smat[`i', 2] = r(mean)
	}
	* inflation and lag: means
	su inflation if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 3] = r(mean)
		mat smat[`i', 4] = r(mean)
	}
	* Wed_unemployment and lag: means
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 5] = r(mean)
		mat smat[`i', 6] = r(mean)
	}
	* Wed_real_pincome_pc1 and lag: means
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 7] = r(mean)
		mat smat[`i', 8] = r(mean)
	}
	* ownsource_rev and lag: means
	su ownsource_rev if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 9] = r(mean)
		mat smat[`i', 10] = r(mean)
	}
	* totallarge and lag: means
	su totallarge if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 11] = r(mean)
		mat smat[`i', 12] = r(mean)
	}
	* real_pincome_pc (mean - 1sd at t=55) and lag (mean - 1sd at t=56)
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 13] = r(mean) - r(sd)
		}
		else {
			mat smat[`i', 13] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 14] = r(mean) - r(sd)
		}
		else {
			mat smat[`i', 14] = r(mean)
		}
	}
	* `var' and lag: ==1
	forv i = 1/`r' {
		mat smat[`i', 15] = 1
		mat smat[`i', 16] = 1
	}
	* real_pincome_pc*`var' and lag: (mean - 1sd at t=55) and lag (mean - 1sd at t=56) 
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 17] = r(mean) - r(sd)
		}
		else {
			mat smat[`i', 17] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 18] = r(mean) - r(sd)
		}
		else {
			mat smat[`i', 18] = r(mean)
		}
	}
	mat list smat

	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_dem.dta", replace version(11)
	restore 

	* Now do the same for non-unified, only changes are for `var' and the interaction:
	* unified govt and lag: ==0
	forv i = 1/`r' {
		mat smat[`i', 15] = 0
		mat smat[`i', 16] = 0
	}
	* real_pincome_pc*`var' and lag: 0
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 17] = 0
		mat smat[`i', 18] = 0
	}
	mat list smat
	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_rep.dta", replace version(11)
	restore 

	* Run program: effectsplot, for "dem" [really, for whatever unified means in `var']
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' income_`var' lincome_`var', shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
	* Run program: effectsplot, for "rep" [really, for whatever non-unified means in `var']
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' income_`var' lincome_`var', shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

	* open, merge both datasets, and create SR and LR plots:
	preserve
	use dem_results.dta, clear
	/* order:
		sort = 1: elementary ed
		sort = 2: higher education
		= 3: transportation
		= 4: public safety
		= 5: natural resources & sanitation
		= 6: housing
		= 7: labor market policy
		= 8: interest on debt
		= 9: other
		= 10: social services (baseline)
 
	And sort_lr will be used for unified govt (sort_dem), and sort_sr (sort_rep) for non-unified
	*/
	rename sort_lr sort_dem
	rename sort_sr sort_rep
	foreach zz of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
		rename `zz' `zz'dem
	}
	joinby sort using rep_results.dta
	foreach ff of varlist var_pie_ll_sr_ - mid_lr {
		rename `ff' `ff'rep
	}
 
	* plot SR and LR across party:
	$graphmakersr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownincome-`var'-sr.pdf", as(pdf) replace
	$graphmakerlr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownincome-`var'-lr.pdf", as(pdf) replace
	restore 
	
	
	* ---------------------------------------------------------------------------
	*	Figure 2: Rise in own unemployment (ssq-fig-ownunemployment-sr.pdf and ssq-fig-ownunemployment-lr.pdf) for SR and LR PDFs, respectively
	* create necessary interactions:
	cap gen unemployment_`var' = unemployment*`var'
	cap gen lunemployment_`var' = lunemployment*l`var'
	* ---------------------------------------------------------------------------
	* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*`var' + l.(ownunemployment*`var'). In other words we're only interacting the variable of interest with `var', rather than everything; this is what we do in the CUP book

	* first one, we'll do `var' == 1
	set seed 29202094
	* init mat:
	mat smat = J(100, 18, .) // t = 100, k = 18
	mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "`var'" "l`var'" "unemployment_`var'" "lunemployment_`var'" 
	loc r = rowsof(smat) 

	* unemployment and lag: (mean + 1sd at t=55) and lag (mean + 1sd at t=56)
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 1] = r(mean) + r(sd)
		}
		else {
			mat smat[`i', 1] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 2] = r(mean) + r(sd)
		}
		else {
			mat smat[`i', 2] = r(mean)
		}
	}
	* inflation and lag: means
	su inflation if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 3] = r(mean)
		mat smat[`i', 4] = r(mean)
	}
	* Wed_unemployment and lag: means
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 5] = r(mean)
		mat smat[`i', 6] = r(mean)
	}
	* Wed_real_pincome_pc1 and lag: means
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 7] = r(mean)
		mat smat[`i', 8] = r(mean)
	}
	* ownsource_rev and lag: means
	su ownsource_rev if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 9] = r(mean)
		mat smat[`i', 10] = r(mean)
	}
	* totallarge and lag: means
	su totallarge if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 11] = r(mean)
		mat smat[`i', 12] = r(mean)
	}
	* real_pincome_pc: means
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 13] = r(mean)
		mat smat[`i', 14] = r(mean)
	}
	* `var' and lag: ==1
	forv i = 1/`r' {
		mat smat[`i', 15] = 1
		mat smat[`i', 16] = 1
	}
	* unemployment*`var' and lag: (mean + 1sd at t=55) and lag (mean + 1sd at t=56) 
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 17] = r(mean) + r(sd)
		}
		else {
			mat smat[`i', 17] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 18] = r(mean) + r(sd)
		}
		else {
			mat smat[`i', 18] = r(mean)
		}
	}
	mat list smat

	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_dem.dta", replace version(11)
	restore 

	* Now do the same for non-unified, only changes are for `var' and the interaction:
	* demgov and lag: ==0
	forv i = 1/`r' {
		mat smat[`i', 15] = 0
		mat smat[`i', 16] = 0
	}
	* real_pincome_pc*`var' and lag: 0
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 17] = 0
		mat smat[`i', 18] = 0
	}
	mat list smat
	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_rep.dta", replace version(11)
	restore 

	* Run program: effectsplot, for "dem" [really, for whatever unified means in `var']
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' unemployment_`var' lunemployment_`var', shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
	* Run program: effectsplot, for "rep" [really, for whatever non-unified means in `var']
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' unemployment_`var' lunemployment_`var', shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

	* open, merge both datasets, and create SR and LR plots:
	preserve
	use dem_results.dta, clear
	/* order:
		sort = 1: elementary ed
		sort = 2: higher education
		= 3: transportation
		= 4: public safety
		= 5: natural resources & sanitation
		= 6: housing
		= 7: labor market policy
		= 8: interest on debt
		= 9: other
		= 10: social services (baseline)
 
	And sort_lr will be used for unified govt (sort_dem), and sort_sr (sort_rep) for non-unified
	*/
	rename sort_lr sort_dem
	rename sort_sr sort_rep
	foreach zz of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
		rename `zz' `zz'dem
	}
	joinby sort using rep_results.dta
	foreach ff of varlist var_pie_ll_sr_ - mid_lr {
		rename `ff' `ff'rep
	}
 
	* plot SR and LR across party:
	$graphmakersr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownunemployment-`var'-sr.pdf", as(pdf) replace
	$graphmakerlr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-ownunemployment-`var'-lr.pdf", as(pdf) replace
	restore 
	
	
	* ---------------------------------------------------------------------------
	*	Figure 3: Drop in surrounding personal income (ssq-fig-surroundincome-sr.pdf and ssq-fig-surroundincome-lr.pdf) for SR and LR PDFs, respectively
	* create necessary interactions:
	cap gen Wincome_`var' = Wed_real_pincome_pc1*`var'
	cap gen lWincome_`var' = lWed_real_pincome_pc1*l`var'
	* ---------------------------------------------------------------------------
	* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*`var' + l.(ownunemployment*`var'). In other words we're only interacting the variable of interest with `var', rather than everything; this is what we do in the CUP book 

	* first one, we'll do demgov == 1
	set seed 29202094
	* init mat:
	mat smat = J(100, 18, .) // t = 100, k = 18
	mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "`var'" "l`var'" "Wincome_`var'" "lWincome_`var'" 
	loc r = rowsof(smat) 

	* unemployment and lag: means
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 1] = r(mean)
		mat smat[`i', 2] = r(mean)
	}
	* inflation and lag: means
	su inflation if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 3] = r(mean)
		mat smat[`i', 4] = r(mean)
	}
	* Wed_unemployment and lag: means
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 5] = r(mean)
		mat smat[`i', 6] = r(mean)
	}
	* Wed_real_pincome_pc1 and lag: (mean - .5sd at t=55) and lag (mean - .5sd at t=56)
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 7] = r(mean) - (.5*r(sd))
		}
		else {
			mat smat[`i', 7] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 8] = r(mean) - (.5*r(sd))
		}
		else {
			mat smat[`i', 8] = r(mean)
		}
	}
	* ownsource_rev and lag: means
	su ownsource_rev if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 9] = r(mean)
		mat smat[`i', 10] = r(mean)
	}
	* totallarge and lag: means
	su totallarge if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 11] = r(mean)
		mat smat[`i', 12] = r(mean)
	}
	* real_pincome_pc: means
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 13] = r(mean)
		mat smat[`i', 14] = r(mean)
	}
* `var' and lag: ==1
	forv i = 1/`r' {
		mat smat[`i', 15] = 1
		mat smat[`i', 16] = 1
	}
	* Wed_real_pincome_pc1*`var' and lag: (mean - .5sd at t=55) and lag (mean - .5sd at t=56) 
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 17] = r(mean) - (r(sd)*.5)
		}
		else {
			mat smat[`i', 17] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 18] = r(mean) - (r(sd)*.5)
		}
		else {
			mat smat[`i', 18] = r(mean)
		}
	}
	mat list smat

	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_dem.dta", replace version(11)
	restore 

	* Now do the same for rep, only changes are for `var' and the interaction:
	* `var' and lag: ==0
	forv i = 1/`r' {
		mat smat[`i', 15] = 0
		mat smat[`i', 16] = 0
	}
	* Wed_real_pincome_pc1*`var' and lag: 0
	forv i = 1/`r' {
		mat smat[`i', 17] = 0
		mat smat[`i', 18] = 0
	}
	mat list smat
	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_rep.dta", replace version(11)
	restore 

	* Run program: effectsplot, for "dem" [really, for whatever unified means in `var']
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' Wincome_`var' lWincome_`var', shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
	* Run program: effectsplot, for "rep" [really, for whatever non-unified means in `var']
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' Wincome_`var' lWincome_`var', shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
	preserve
	use dem_results.dta, clear
	/* order:
		sort = 1: elementary ed
		sort = 2: higher education
		= 3: transportation
		= 4: public safety
		= 5: natural resources & sanitation
		= 6: housing
		= 7: labor market policy
		= 8: interest on debt
		= 9: other
		= 10: social services (baseline)
 
	And sort_lr will be used for unified govt (sort_dem), and sort_sr (sort_rep) for non-unified
	*/
	rename sort_lr sort_dem
	rename sort_sr sort_rep
	foreach zz of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
		rename `zz' `zz'dem
	}
	joinby sort using rep_results.dta
	foreach ff of varlist var_pie_ll_sr_ - mid_lr {
		rename `ff' `ff'rep
	}
 
	* plot SR and LR across party:
	$graphmakersr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundincome-`var'-sr.pdf", as(pdf) replace
	$graphmakerlr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundincome-`var'-lr.pdf", as(pdf) replace
	restore
	
	
	* ---------------------------------------------------------------------------
	*	Figure 4: Rise in surrounding unemployment (ssq-fig-surroundunemployment-sr.pdf and ssq-fig-surroundunemployment-lr.pdf) for SR and LR PDFs, respectively
	* create necessary interactions:
	cap gen Wunemployment_`var' = Wed_unemployment1*`var'
	cap gen lWunemployment_`var' = lWed_unemployment1*l`var'
	* ---------------------------------------------------------------------------
	* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*`var' + l.(ownunemployment*`var'). In other words we're only interacting the variable of interest with `var', rather than everything; this is what we do in the CUP book 

	* first one, we'll do `var' == 1
	set seed 29202094
	* init mat:
	mat smat = J(100, 18, .) // t = 100, k = 18
	mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "`var'" "l`var'" "Wunemployment_`var'" "lWunemployment_`var'" 
	loc r = rowsof(smat) 

	* unemployment and lag: means
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 1] = r(mean)
		mat smat[`i', 2] = r(mean)
	}
	* inflation and lag: means
	su inflation if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 3] = r(mean)
		mat smat[`i', 4] = r(mean)
	}
	* Wed_unemployment and lag: (mean + .5sd at t=55) and lag (mean + .5sd at t=56)
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 5] = r(mean) + (.5*r(sd))
		}
		else {
			mat smat[`i', 5] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 6] = r(mean) + (.5*r(sd))
		}
		else {
			mat smat[`i', 6] = r(mean)
		}
	}
	* Wed_real_pincome_pc1 and lag: means
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 7] = r(mean)
		mat smat[`i', 8] = r(mean)
	}
	* ownsource_rev and lag: means
	su ownsource_rev if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 9] = r(mean)
		mat smat[`i', 10] = r(mean)
	}
	* totallarge and lag: means
	su totallarge if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 11] = r(mean)
		mat smat[`i', 12] = r(mean)
	}
	* real_pincome_pc: means
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 13] = r(mean)
		mat smat[`i', 14] = r(mean)
	}
	* `var' and lag: ==1
	forv i = 1/`r' {
		mat smat[`i', 15] = 1
		mat smat[`i', 16] = 1
	}
	* Wed_unemployment1*`var' and lag: (mean + .5sd at t=55) and lag (mean + 1sd at t=56) 
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 17] = r(mean) + (r(sd)*.5)
		}
		else {
			mat smat[`i', 17] = r(mean)
		}
		if `i' >= 56 {
			mat smat[`i', 18] = r(mean) + (r(sd)*.5)
		}
		else {
			mat smat[`i', 18] = r(mean)
		}
	}
	mat list smat

	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_dem.dta", replace version(11)
	restore 

	* Now do the same for rep, only changes are for `var' and the interaction:
	* `var' and lag: ==0
	forv i = 1/`r' {
		mat smat[`i', 15] = 0
		mat smat[`i', 16] = 0
	}
	* Wed_real_pincome_pc1*`var' and lag: 0
	forv i = 1/`r' {
		mat smat[`i', 17] = 0
		mat smat[`i', 18] = 0
	}
	mat list smat
	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_rep.dta", replace version(11)
	restore 

	* Run program: effectsplot, for "dem" [really, for whatever unified means in `var']
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' Wunemployment_`var' lWunemployment_`var', shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
	* Run program: effectsplot, for "rep" [really, for whatever non-unified means in `var']
dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var' Wunemployment_`var' lWunemployment_`var', shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
	preserve
	use dem_results.dta, clear
	/* order:
		sort = 1: elementary ed
		sort = 2: higher education
		= 3: transportation
		= 4: public safety
		= 5: natural resources & sanitation
		= 6: housing
		= 7: labor market policy
		= 8: interest on debt
		= 9: other
		= 10: social services (baseline)
 
	And sort_lr will be used for unified govt (sort_dem), and sort_sr (sort_rep) for non-unified
	*/
	rename sort_lr sort_dem
	rename sort_sr sort_rep
	foreach zz of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
		rename `zz' `zz'dem
	}
	joinby sort using rep_results.dta
	foreach ff of varlist var_pie_ll_sr_ - mid_lr {
		rename `ff' `ff'rep
	}
 
	* plot SR and LR across party:
	$graphmakersr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundunemployment-`var'-sr.pdf", as(pdf) replace
	$graphmakerlr
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-surroundunemployment-`var'-lr.pdf", as(pdf) replace
	restore
	
	
	* ---------------------------------------------------------------------------
	*	Figure 5: party switching (ssq-fig-partyswitch-sr.pdf and ssq-fig-partyswitch-lr.pdf) for SR and LR PDFs, respectively

	* ---------------------------------------------------------------------------
	* Step 1, set up the matrix. This model will be y = l.y + x + l.x + ownunemployment*demgov + l.(ownunemployment*`var'). In other words we're only interacting the variable of interest with `var', rather than everything; this is what we do in the CUP book 

	* first one, we'll do `var' == 1
	set seed 29202094
	* init mat:
	mat smat = J(100, 16, .) // t = 100, k = 16
	mat colnames smat = "unemployment" "lunemployment" "inflation" "linflation" "Wed_unemployment1" "lWed_unemployment1" "Wed_real_pincome_pc1" "lWed_real_pincome_pc1" "ownsource_rev" "lownsource_rev" "totallarge" "ltotallarge" "real_pincome_pc" "lreal_pincome_pc" "`var'" "l`var'" 
	loc r = rowsof(smat) 

	* unemployment and lag: means
	su unemployment if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 1] = r(mean)
		mat smat[`i', 2] = r(mean)
	}
	* inflation and lag: means
	su inflation if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 3] = r(mean)
		mat smat[`i', 4] = r(mean)
	}
	* Wed_unemployment and lag: means
	su Wed_unemployment1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 5] = r(mean)
		mat smat[`i', 6] = r(mean)
	}
	* Wed_real_pincome_pc1 and lag: means
	su Wed_real_pincome_pc1 if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 7] = r(mean)
		mat smat[`i', 8] = r(mean)
	}
	* ownsource_rev and lag: means
	su ownsource_rev if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 9] = r(mean)
		mat smat[`i', 10] = r(mean)
	}
	* totallarge and lag: means
	su totallarge if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 11] = r(mean)
		mat smat[`i', 12] = r(mean)
	}
	* real_pincome_pc: means
	su real_pincome_pc if tabbs == 1
	forv i = 1/`r' {
		mat smat[`i', 13] = r(mean)
		mat smat[`i', 14] = r(mean)
	}
	* `var' and lag: == 0 til 55, then 1 (lag gets = 1 at t=56). Non-unified to unified
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 15] = 1
		}
		else {
			mat smat[`i', 15] = 0
		}
		if `i' >= 56 {
			mat smat[`i', 16] = 1
		}
		else {
			mat smat[`i', 16] = 0
		}
	}
	mat list smat

	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_dem.dta", replace version(11)
	restore 

	* Now do the same for unified to nonunified
	forv i = 1/`r' {
		if `i' >= 55 {
			mat smat[`i', 15] = 0
		}
		else {
			mat smat[`i', 15] = 1
		}
		if `i' >= 56 {
			mat smat[`i', 16] = 0
		}
		else {
			mat smat[`i', 16] = 1
		}
	}

	mat list smat
	preserve
	clear
	svmat smat, names(col)
	saveold "savedshocks_rep.dta", replace version(11)
	restore 

	* Run program: effectsplot, for non-unified -> unified
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var', shockdta(savedshocks_dem) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(dem_results)
	* Run program: effectsplot, for unified -> non-unified
	dspcstsldvany unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc `var' l`var', shockdta(savedshocks_rep) dvs($dvs) id(fips) basetime(51) shocktime(55) endtime(100) ladderplot saving(rep_results)

* open, merge both datasets, and create SR and LR plots:
	preserve
	use dem_results.dta, clear
	/* order:
		sort = 1: elementary ed
		sort = 2: higher education
		= 3: transportation
		= 4: public safety
		= 5: natural resources & sanitation
		= 6: housing
		= 7: labor market policy
		= 8: interest on debt
		= 9: other
		= 10: social services (baseline)
 
	And sort_lr will be used for non-unified to unified (sort_dem), and sort_sr (sort_rep) for unified to non-unified
	*/
	rename sort_lr sort_dem
	rename sort_sr sort_rep
	foreach zz of varlist var_pie_ll_sr_ - var_pie_ul90_lr_ mid_sr mid_lr {
		rename `zz' `zz'dem
	}
	joinby sort using rep_results.dta
	foreach ff of varlist var_pie_ll_sr_ - mid_lr {
		rename `ff' `ff'rep
	}
 
	* plot SR and LR across party:
	$graphmakersrpartyswitch
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-partyswitch-`var'-sr.pdf", as(pdf) replace
	$graphmakerlrpartyswitch
	graph export "SSQ 2023/RnR/RnR-updated-figures/ssq-fig-partyswitch-`var'-lr.pdf", as(pdf) replace
	restore 
	
} // close SI loop


* --------------- MAKING TABLE FOR PAPER ------------------------
eststo clear
eststo: sureg (eled_ss l.eled_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(hed_ss l.hed_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(trans_ss l.trans_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(safety_ss l.safety_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(env_ss l.env_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(hous_ss l.hous_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(lm_ss l.lm_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(debt_ss l.debt_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov) ///
			(other_ss l.other_ss unemployment lunemployment inflation linflation Wed_unemployment1 lWed_unemployment1 Wed_real_pincome_pc1 lWed_real_pincome_pc1 ownsource_rev lownsource_rev totallarge ltotallarge real_pincome_pc lreal_pincome_pc demgov ldemgov)


esttab using table1.tex, unstack replace se(3) star(* 0.10 ** 0.05 *** 0.01) sca("N Obs." "N_g Countries" "ar2 Adjusted R-Sq." "ll Log Lik." "chi2 $\chi^2$" "chi2_c Prob $ > \chi^2$" ) title(blank) addn(Regression with standard errors in parentheses. Two-tail tests.) b(3) 



 







