# 03/26/17
# Andy Philips
# Generate Fractionally Integrated series for analysis in Stata
# -------------------------------------- #
rm( list = ls() )
set.seed(2034901)
library(fracdiff)
library(foreign)
#---------------------------------------#
# PART I: SPURIOUSLY RELATED FRAC X AND Y
#---------------------------------------#

# Use the following DGPs:
# 1. N = 35, d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
# 2. N = 35, d = 0.8, b = 0, beta = 0 (infinite variance)
# 3. N = 50, , d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
# 4. N = 50, d = 0.8, b = 0, beta = 0 (infinite variance)
# 5. N = 80, , d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
# 6. N = 80, , d = 0.8, b = 0, beta = 0 (infinite variance)

# note: since d = 0.8 -> -0.2 since it is first-differenced, I need an
# extra observation so I can undifference.
# -----------------


# 1. N = 35, d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
part1_case1_y <- matrix(NA,nrow=35,ncol=1000)
part1_case1_x <- matrix(NA,nrow=35,ncol=1000)
for(i in 1:ncol(part1_case1_y)) {
	sim1 <- fracdiff.sim(35, d = 0.4, n.start = 100, innov = rnorm(35))
	part1_case1_y[,i] <- sim1$series
 	sim2 <- fracdiff.sim(35, d = 0.4, n.start = 100, innov = rnorm(35))
 	part1_case1_x[,i] <- sim2$series
}
part1_case1 <- cbind(part1_case1_y,part1_case1_x)
write.csv(part1_case1, file = "part1_case1.csv")

# 2. N = 35, d = 0.8, b = 0, beta = 0 (infinite variance). Note that since fracdiff doesn't accept d > 0.5, you have to take integer first difference.
part1_case2_y <- matrix(NA,nrow=35,ncol=1000)
part1_case2_x <- matrix(NA,nrow=35,ncol=1000)
for(i in 1:ncol(part1_case2_y)) {
	sim1 <- fracdiff.sim(35, d = -0.2, n.start = 100, innov = rnorm(35))
	part1_case2_y[,i] <- diffinv(sim1$series, xi = rnorm(1))[-1]
	sim2 <- fracdiff.sim(35, d = -0.2, n.start = 100, innov = rnorm(35))
	part1_case2_x[,i] <- diffinv(sim2$series, xi = rnorm(1))[-1]
}
part1_case2 <- cbind(part1_case2_y, part1_case2_x)
write.csv(part1_case2, file = "part1_case2.csv")

# 3. N = 50, , d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
part1_case3_y <- matrix(NA,nrow=50,ncol=1000)
part1_case3_x <- matrix(NA,nrow=50,ncol=1000)
for(i in 1:ncol(part1_case3_y)) {
	sim1 <- fracdiff.sim(50, d = 0.4, n.start = 100, innov = rnorm(50))
	part1_case3_y[,i] <- (sim1$series)
	sim2 <- fracdiff.sim(50, d = 0.4, n.start = 100, innov = rnorm(50))
	part1_case3_x[,i] <- (sim2$series)
}
part1_case3 <- cbind(part1_case3_y,part1_case3_x)
write.csv(part1_case3, file = "part1_case3.csv")

# 4. N = 50, d = 0.8, b = 0, beta = 0 (infinite variance)
part1_case4_y <- matrix(NA,nrow=50,ncol=1000)
part1_case4_x <- matrix(NA,nrow=50,ncol=1000)
for(i in 1:ncol(part1_case4_y)) {
	sim1 <- fracdiff.sim(50, d = -0.2, n.start = 100, innov = rnorm(50))
	part1_case4_y[,i] <- diffinv(sim1$series, xi = rnorm(1))[-1]
	sim2 <- fracdiff.sim(50, d = -0.2, n.start = 100, innov = rnorm(50))
	part1_case4_x[,i] <- diffinv(sim2$series, xi = rnorm(1))[-1]
}
part1_case4 <- cbind(part1_case4_y, part1_case4_x)
write.csv(part1_case4, file = "part1_case4.csv")

# 5. N = 80, , d = 0.4, b = 0, beta = 0 (finite variance and mean-reverting)
part1_case5_y <- matrix(NA,nrow=80,ncol=1000)
part1_case5_x <- matrix(NA,nrow=80,ncol=1000)
for(i in 1:ncol(part1_case5_y)) {
	sim1 <- fracdiff.sim(80, d = 0.4, n.start = 100, innov = rnorm(80))
	part1_case5_y[,i] <- sim1$series
	sim2 <- fracdiff.sim(80, d = 0.4, n.start = 100, innov = rnorm(80))
	part1_case5_x[,i] <- sim2$series
}
part1_case5 <- cbind(part1_case5_y,part1_case5_x)
write.csv(part1_case5, file = "part1_case5.csv")

# 6. N = 80, , d = 0.8, b = 0, beta = 0 (infinite variance)
part1_case6_y <- matrix(NA,nrow=80,ncol=1000)
part1_case6_x <- matrix(NA,nrow=80,ncol=1000)
for(i in 1:ncol(part1_case6_y)) {
	sim1 <- fracdiff.sim(80, d = -0.2, n.start = 100, innov = rnorm(80))
	part1_case6_y[,i] <- diffinv(sim1$series, xi = rnorm(1))[-1]
	sim2 <- fracdiff.sim(80, d = -0.2, n.start = 100, innov = rnorm(80))
	part1_case6_x[,i] <- diffinv(sim2$series, xi = rnorm(1))[-1]
}
part1_case6 <- cbind(part1_case6_y, part1_case6_x)
write.csv(part1_case6, file = "part1_case6.csv")

#---------------------------------------#
# PART II: FRAC COINTEGRATED X AND Y
#---------------------------------------#

# use the following DGPs:
# 1. N = 35, d = 0.4, b = 0.4, beta = 0.5 (finite variance and mean-reverting). Remember that y's I(d) = (d-b)
part2_case1_y <- matrix(NA,nrow=35,ncol=1000)
part2_case1_x <- matrix(NA,nrow=35,ncol=1000)
for(i in 1:ncol(part2_case1_y)) {
	sim.x <- fracdiff.sim(35, d = 0.4, n.start = 100, innov = rnorm(35))
	part2_case1_x[,i] <- sim.x$series
	sim.y <- fracdiff.sim(35, d = 0, n.start = 100)
	part2_case1_y[,i] <- 0.5*sim.x$series + sim.y$series
}
part2_case1 <- cbind(part2_case1_y, part2_case1_x)
write.csv(part2_case1, file = "part2_case1.csv")


# 2. N = 35, d = 0.8, b = 0.6, beta = 0.5 (infinite variance)
part2_case2_y <- matrix(NA,nrow=35,ncol=1000)
part2_case2_x <- matrix(NA,nrow=35,ncol=1000)
for(i in 1:ncol(part2_case2_y)) {
	sim.x <- fracdiff.sim(35, d = -0.2, n.start = 100, innov = rnorm(35))
	x.levels <- diffinv(sim.x$series, xi = rnorm(1))[-1]
	part2_case2_x[,i] <- x.levels
	sim.y <- fracdiff.sim(35, d = 0.2, n.start = 100)
  y.levels <- 0.5*x.levels + sim.y$series
	part2_case2_y[,i] <- y.levels
}
part2_case2 <- cbind(part2_case2_y, part2_case2_x)
write.csv(part2_case2, file = "part2_case2.csv")

# 3. N = 50, d = 0.4, b = 0.4, beta = 0.5 (finite variance and mean-reverting)
part2_case3_y <- matrix(NA,nrow=50,ncol=1000)
part2_case3_x <- matrix(NA,nrow=50,ncol=1000)
for(i in 1:ncol(part2_case3_y)) {
	sim.x <- fracdiff.sim(50, d = 0.4, n.start = 100, innov = rnorm(50))
	part2_case3_x[,i] <- sim.x$series
	sim.y <- fracdiff.sim(50, d = 0, n.start = 100)
	part2_case3_y[,i] <- 0.5*sim.x$series + sim.y$series
}
part2_case3 <- cbind(part2_case3_y, part2_case3_x)
write.csv(part2_case3, file = "part2_case3.csv")

# 4. N = 50, d = 0.8, b = 0.6, beta = 0.5 (infinite variance)
part2_case4_y <- matrix(NA,nrow=50,ncol=1000)
part2_case4_x <- matrix(NA,nrow=50,ncol=1000)
for(i in 1:ncol(part2_case4_y)) {
	sim.x <- fracdiff.sim(50, d = -0.2, n.start = 100, innov = rnorm(50))
	x.levels <- diffinv(sim.x$series, xi = rnorm(1))[-1]
	part2_case4_x[,i] <- x.levels
	sim.y <- fracdiff.sim(50, d = 0.2, n.start = 100)
	y.levels <- 0.5*x.levels + sim.y$series
	part2_case4_y[,i] <- y.levels
}
part2_case4 <- cbind(part2_case4_y, part2_case4_x)
write.csv(part2_case4, file = "part2_case4.csv")

# 5. N = 80, d = 0.4, b = 0.4, beta = 0 (finite variance and mean-reverting)
part2_case5_y <- matrix(NA,nrow=80,ncol=1000)
part2_case5_x <- matrix(NA,nrow=80,ncol=1000)
for(i in 1:ncol(part2_case5_y)) {
	sim.x <- fracdiff.sim(80, d = 0.4, n.start = 100, innov = rnorm(80))
	part2_case5_x[,i] <- sim.x$series
	sim.y <- fracdiff.sim(80, d = 0, n.start = 100)
	part2_case5_y[,i] <- 0.5*sim.x$series + sim.y$series
}
part2_case5 <- cbind(part2_case5_y, part2_case5_x)
write.csv(part2_case5, file = "part2_case5.csv")

# 6. N = 80,  d = 0.8, b = 0.6, beta = 0.5 (infinite variance)
part2_case6_y <- matrix(NA,nrow=80,ncol=1000)
part2_case6_x <- matrix(NA,nrow=80,ncol=1000)
for(i in 1:ncol(part2_case6_y)) {
	sim.x <- fracdiff.sim(80, d = -0.2, n.start = 100, innov = rnorm(80))
	x.levels <- diffinv(sim.x$series, xi = rnorm(1))[-1]
	part2_case6_x[,i] <- x.levels
	sim.y <- fracdiff.sim(80, d = 0.2, n.start = 100)
	y.levels <- 0.5*x.levels + sim.y$series
	part2_case6_y[,i] <- y.levels
}
part2_case6 <- cbind(part2_case6_y, part2_case6_x)
write.csv(part2_case6, file = "part2_case6.csv")


